"""Use the frozen review generators/panels, compare the two public paths after warm-up."""
import json
from pathlib import Path
import sys
import time
import warnings
from unittest.mock import patch
from tempfile import TemporaryDirectory
import numpy as np
from _harness import power_state
from mixmogam import gwas, hratt_step2, HrattStep1, GwasResult
from mixmogam.io.pgen import iter_pgen

ROOT = Path.cwd()
BUDGET = 16 * 1024**2
records = []
power_state()

def timed(label, mode, rep, fn, verify):
    before = time.perf_counter()
    result = fn()
    sec = time.perf_counter() - before
    stats = verify(result)
    record = dict(task=label, mode=mode, rep=rep, seconds=sec, **stats)
    if rep >= 0:
        records.append(record)
    print(label, mode, rep, sec, flush=True)
    return result

def parity(ref, result):
    for k in ('p','f_stat','beta','se','af'):
        np.testing.assert_allclose(getattr(ref,k),getattr(result,k),rtol=3e-10,atol=2e-11)
    for k in ('chromosome','position','variant_ids','effect_allele','other_allele'):
        np.testing.assert_array_equal(np.asarray(getattr(ref,k)).astype(str),
                                      np.asarray(getattr(result,k)).astype(str))
    return float(np.nanmax(np.abs(ref.p-result.p)))

def pgen():
    fits = [HrattStep1.load(ROOT/f'step1-1-{t}.npz') for t in range(4)]
    ordered = [HrattStep1.load(ROOT/f'step1-0-{t}.npz') for t in range(4)]
    for file in ('sparse-panel','mixed-control','dense-control'):
        path = ROOT / file
        def run(mode, fits=fits):
            source = path if mode=='native' else iter_pgen(path,packed=mode=='packed',chunk_bytes=BUDGET)
            return hratt_step2(fits, source, chunk_bytes=BUDGET)
        ref = run('packed')
        for a,b in zip(run('packed',ordered),run('native',ordered)):
            parity(a,b)
        modes = ['native','packed','int8']
        for rep in range(-1,3):
            for i in range(3):
                mode = modes[(i+rep)%3]
                timed(file,mode,rep,lambda: run(mode),
                      lambda out: {'max_p':max(parity(x,y) for x,y in zip(ref,out))})
    fit = HrattStep1.load(ROOT/'highn-step1.npz')
    with TemporaryDirectory() as tmp:
        name = Path(tmp)/'scores.tsv'
        ref = hratt_step2(fit,iter_pgen(ROOT/'highn',chunk_bytes=BUDGET),chunk_bytes=BUDGET)
        def run_high(mode):
            source=ROOT/'highn'
            if mode!='native':
                source=iter_pgen(source,packed=mode=='packed',chunk_bytes=BUDGET)
            return hratt_step2(fit,source,chunk_bytes=BUDGET,out=name)
        def verify(summary):
            assert summary['variants']==1024
            return {'max_p':parity(ref,GwasResult.read_csv(name))}
        for rep in range(-1,3):
            for i in range(3):
                mode=modes[(i+rep)%3]
                timed('highn-file',mode,rep,lambda:run_high(mode),verify)

def bolt():
    from bolt_probe import Y, gt, X, seed, compare
    from mixmogam._loco import LocoGenotypes
    from mixmogam.lmm import LMM
    current = {}
    def run(mode):
        calls, stops = [0,0], []
        matmul, loco, target = LocoGenotypes.matmul,LocoGenotypes.matmul_loco,LMM._slq_target
        def m(self,*a,**kw):
            calls[0]+=1
            return matmul(self,*a,**kw)
        def l(self,*a,**kw):
            calls[1]+=1
            return loco(self,*a,**kw)
        def monitor(self,*a,**kw):
            y,coef,stop=target(self,*a,**kw)
            idx=len(stops)
            stops.append(24)
            def wrapped(j, rules):
                done=stop(j,rules)
                if done: stops[idx]=j
                return done
            return y,coef,wrapped
        with patch.object(LocoGenotypes,'matmul',m),patch.object(LocoGenotypes,'matmul_loco',l),patch.object(LMM,'_slq_target',monitor),warnings.catch_warnings(record=True) as caught:
            warnings.simplefilter('always')
            options=dict(X=X,method='bolt-inf',random_state=seed)
            out=(gwas(np.column_stack(Y),gt,**options) if mode=='batch' else
                 [gwas(y,gt,**options) for y in Y])
        current.update(full=calls[0],loco=calls[1],stops=stops,warnings=[str(w.message) for w in caught])
        return out
    ref=run('independent')
    ref_stops,ref_warnings=current['stops'],current['warnings']
    def verify(out):
        assert current['stops']==ref_stops and current['warnings']==ref_warnings,current
        return {**current,'delta':compare(ref,out)}
    for rep in range(-1,4):
        for mode in (['batch','independent'] if rep%2 else ['independent','batch']):
            timed('bolt',mode,rep,lambda:run(mode),verify)

def gram():
    from gram_probe import y,gt,X
    with TemporaryDirectory() as tmp:
        def run(mode):
            with warnings.catch_warnings():
                warnings.simplefilter('ignore')
                options={'gram_cache_bytes':100_000_000 if mode=='ram' else 2_000_000}
                if mode=='spill':options['gram_cache_dir']=tmp
                return gwas(y,gt,X=X,method='hratt',heritability_method='he',random_state=383,
                            n_threads=1,**options)
        ref=run('ram')
        def verify(out):
            for k in ('p','f_stat','beta','se','af'):
                np.testing.assert_array_equal(getattr(out,k),getattr(ref,k))
            assert out.extra['cv_converged'] and out.extra['loco_converged']
            assert not list(Path(tmp).iterdir())
            return dict(cache=out.extra['gram_cache'],iterations=out.extra['loco_iterations'])
        modes=['partial','ram','spill']
        for rep in range(-1,3):
            for i in range(3):
                mode=modes[(i+rep)%3]
                timed('gram',mode,rep,lambda:run(mode),verify)

if __name__=='__main__':
    action=sys.argv[1]
    {'pgen':pgen, 'bolt':bolt, 'gram':gram}[action]()
    Path(action+'.json').write_text(json.dumps(records,indent=2,
        default=lambda x: x.item() if isinstance(x,np.generic) else x.tolist()))
