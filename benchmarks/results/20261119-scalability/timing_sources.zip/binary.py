"""Single-chromosome binary step 2; same binary outcome, covariates and offsets for both versions."""
import json
import sys
import resource
from pathlib import Path
from time import perf_counter
import numpy as np
from mixmogam import Genotypes,twostep
from mixmogam._loco import LocoGenotypes
from dataclasses import replace
from _harness import power_state

power_state()
label=sys.argv[1]
n,g,q=32768,22,11
rng=np.random.default_rng(61)
X=rng.normal(size=(n,q-1))
y=(rng.random(n)<1/(1+np.exp(1.1+X[:,0]/2))).astype(float)
calls=rng.binomial(2,.28,size=(n,g*2)).astype('i1')
gt=Genotypes(calls,chromosome=np.repeat(np.arange(g),2),packed=True)
st=twostep._setup(y,gt,X,25,128,trait='binary')
test=Genotypes(calls[:,:2],chromosome=[0,0],packed=True)
lg=LocoGenotypes(test,np.array([0,0]),st.lg.Q,n_groups=g,block=128,row_scale=st.s)
st=replace(st,lg=lg)
pred=rng.normal(size=(n,g))*.02
cache={}
start=perf_counter()
out=twostep._hratt_binary_step2(st,test,pred,1.,1.,2.,1,{},cache=cache)
sec=perf_counter()-start
ref=Path('binary-reference.npz')
if label=='before':
    np.savez(ref,p=out.p,beta=out.beta,se=out.se,f_stat=out.f_stat)
else:
    with np.load(ref) as a:
        for key in a:np.testing.assert_allclose(a[key],getattr(out,key),rtol=2e-10,atol=2e-13)
rec=dict(version=label,n=n,groups=g,covariate_columns=q,active_groups=1,
    seconds=sec,peak_bytes=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss * (1 if sys.platform == "darwin" else 1024),
    null_converged=out.extra['null_converged'],offset_sd=out.extra['offset_sd'])
print(json.dumps(rec))
