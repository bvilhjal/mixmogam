"""Real layout-2 reader comparison, with a warmed upstream file index."""
from pathlib import Path
from time import perf_counter
from tempfile import TemporaryDirectory
import json
import numpy as np
from _harness import power_state
from tests.bgen_fixture import write_bgen
from mixmogam.io.bgen import iter_bgen_dosages

power_state()
rng=np.random.default_rng(15)
n,m=8192,768
budget=8*1024**2
rows=[]
with TemporaryDirectory() as tmp:
    for bits in (8,16):
        denom=(1<<bits)-1
        path=Path(tmp)/f"panel{bits}.bgen"
        ids=[f"id{i}" for i in range(n)]
        rec=[]
        for j in range(m):
            a=rng.integers(0,denom+1,n,dtype=np.uint32)
            h=rng.integers(0,denom+1-a,size=n,dtype=np.uint32)
            flags=np.where(rng.random(n)<.01,130,2).astype('u1')
            ab=np.column_stack([a,h]).astype(f'<u{bits//8}')
            ab[flags==130]=0
            rec.append((f'v{j}',str(j%2+1),j+1,'A','C',bits,ab,flags))
        write_bgen(path,ids,rec)
        truth=np.column_stack([np.where(r[-1]==130,np.nan,
            (2.*denom-2*r[-2][:,0].astype(float)-r[-2][:,1])/denom) for r in rec])
        del rec
        def run(mode):
            with np.errstate(invalid='ignore'):
                before=perf_counter()
                values=np.column_stack([b.values for b in
                    iter_bgen_dosages(path,backend=mode,chunk_bytes=budget)])
                sec=perf_counter()-before
            np.testing.assert_allclose(values,truth,rtol=0,atol=6e-16)
            return sec,float(np.nanmax(abs(values-truth)))
        for rep in range(-1,3):
            for mode in (['auto','reader'] if rep%2 else ['reader','auto']):
                sec,err=run(mode)
                if rep>=0:rows.append(dict(bits=bits,n=n,m=m,rep=rep,mode=mode,seconds=sec,max_error=err))
                print(bits,mode,rep,sec,err,flush=True)
Path('bgen.json').write_text(json.dumps(rows,indent=2))
