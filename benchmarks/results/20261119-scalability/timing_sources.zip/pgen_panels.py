"""Create the four synthetic PGEN panels and saved HRATT fits in the working directory."""
from pathlib import Path
import shutil
import numpy as np
import pgenlib
from mixmogam import Genotypes, hratt_step1, HrattStep1

root = Path.cwd()
prefix = root / 'sparse-panel'
n = 16385
m = 4096
ng = 4
T = 4
budget = 16 * 1024**2

def panel():
    rng = np.random.default_rng(20261119)
    with (prefix.with_suffix('.psam')).open('w') as fh:
        fh.write('#IID\n')
        for i in range(n): fh.write(f'S{i}\n')
    with (prefix.with_suffix('.pvar')).open('w') as info, pgenlib.PgenWriter(bytes(prefix.with_suffix('.pgen')),n,variant_ct=m) as writer:
        info.write('#CHROM\tPOS\tID\tREF\tALT\n')
        modal_two = 0
        for j in range(m):
            modal = 2 if j % 5 == 0 else 0
            modal_two += modal == 2
            g = np.full(n,modal,np.int8)
            k = 0 if j % 103 == 2 else int(rng.integers(2,91))
            rows = rng.choice(n, size=k, replace=False)
            g[rows] = rng.choice(np.array([-9, 1, 2-modal], np.int8), k, p=[.12,.83,.05])
            if j == 3: g[:20] = 1
            # Small dense control (also exercises switching backend and stitching labels).
            if j % 1024 >= 1000: g = rng.binomial(2,.32,n).astype(np.int8)
            writer.append_biallelic(g)
            info.write(f'{1+j % ng}\t{j+1}\tv{j}\tA\tG\n')

    train_calls = np.asfortranarray(rng.binomial(2,rng.uniform(.1,.5,96),size=(n,96)).astype('i1'))
    all_ids = np.array([f'S{i}' for i in range(n)])
    X = rng.standard_normal((n,3))
    Y = rng.normal(size=(n,T)) + train_calls[:, 8:20] @ rng.normal(size=(12,T)) * .2
    Y[:20, 0] += 3
    fits = []
    for ordered in (True, False):
        rows = np.arange(n) if ordered else rng.permutation(n)[:-101]
        gt = Genotypes(train_calls[rows], chromosome=np.tile(np.arange(1,ng+1),24),
                       sample_ids=all_ids[rows],packed=True)
        block = []
        for k in range(T):
            f = hratt_step1(Y[rows,k], gt, X[rows], heritability_method='he',
                            structure_snps=64, random_state=339)
            assert f.extra['cv_converged'] and f.extra['loco_converged']
            # Force the serialized path and prevent holding a training panel per trait.
            filename = root / f'step1-{int(ordered)}-{k}.npz'
            f.save(filename)
            block.append(HrattStep1.load(filename))
        fits.append(block)
    return fits

def make_mix(frac_dense, name):
    path = root / name
    for ext in ('.psam','.pvar'):
        shutil.copyfile(prefix.with_suffix(ext), path.with_suffix(ext))
    rng = np.random.default_rng(4941)
    gen = np.empty(n,np.int8)
    with pgenlib.PgenReader(bytes(prefix.with_suffix('.pgen'))) as reader,pgenlib.PgenWriter(bytes(path.with_suffix('.pgen')),n,variant_ct=m) as writer:
        for j in range(m):
            if rng.uniform() < frac_dense: gen[:] = rng.binomial(2, rng.uniform(.12,.49), n)
            else: reader.read(j,gen)
            writer.append_biallelic(gen)
    return path

p=root/'highn'
fitpath=root/'highn-step1.npz'
N=500000
M=1024

def make():
    rng=np.random.default_rng(19284)
    ids=np.asarray([f'S{i}' for i in range(N)])
    X=rng.normal(size=(N,2))
    train=np.empty((24,N),np.int8)
    for j in range(train.shape[0]):
        train[j]=rng.binomial(2,rng.uniform(.15,.45),N)
    y=rng.normal(size=N)+.4*train[0]+.3*train[12]+.15*X[:,1]
    gt=Genotypes(train.T,chromosome=np.repeat([1,2],12),sample_ids=ids,packed=True)
    del train
    fit=hratt_step1(y,gt,X,alphas=(-.25,),he_probes=4,grid=[(.5,.3)],
                    heritability_method='he',structure_snps=16,random_state=82)
    assert fit.extra['cv_converged'] and fit.extra['loco_converged']
    fit.save(fitpath)
    with p.with_suffix('.psam').open('w') as fh:
        fh.write('#IID\n')
        fh.writelines(s+'\n' for s in ids)
    del fit,gt,ids,X,y
    with p.with_suffix('.pvar').open('w') as fh,pgenlib.PgenWriter(bytes(p.with_suffix('.pgen')),N,variant_ct=M) as wr:
        fh.write('#CHROM\tPOS\tID\tREF\tALT\n')
        for j in range(M):
            if j%32==0:
                g=rng.binomial(2,.35,N).astype(np.int8)
            else:
                modal=0 if j%5 else 2
                g=np.full(N,modal,np.int8)
                k=0 if j%79==2 else int(rng.integers(2,170))
                ix=rng.choice(N,k,replace=False)
                g[ix]=rng.choice(np.array([-9,1,2-modal],np.int8),k,p=[.12,.83,.05])
            wr.append_biallelic(g)
            fh.write(f'{1+j%2}\t{j+1}\tv{j}\tA\tG\n')

if __name__ == '__main__':
    panel()
    make_mix(.5, 'mixed-control')
    make_mix(1., 'dense-control')
    make()
