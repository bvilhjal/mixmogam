import numpy as np
from mixmogam import Genotypes

n, m, count = 2048, 4096, 4
seed = 662
rng = np.random.default_rng(5458)
G = np.empty((m,n),np.int8)
for j in range(m):
    G[j] = rng.binomial(2, rng.uniform(.07,.48),n)
X = rng.normal(size=(n,4))
Y = []
for t, true_h2 in enumerate((.1,.35,.65,.85)):
    idx = rng.choice(m,120,replace=False)
    genetic = rng.normal(size=120) @ G[idx].astype(float)
    Y.append(np.sqrt(true_h2) * genetic / genetic.std() + np.sqrt(1.-true_h2) * rng.normal(size=n) + .25*X[:,t])
for j in range(0,m,128):
    g = G[j:j+128]
    g[rng.random(g.shape)<.008] = -1
gt = Genotypes(G.T, chromosome=np.repeat(np.arange(1,9),m//8),packed=True)
del G

def compare(ref,out):
    d={}
    for base,cur in zip(ref,out):
        for key in ('p','f_stat','beta','se','af'):
            a,b=getattr(base,key),getattr(cur,key)
            np.testing.assert_allclose(a,b,rtol=2e-5,atol=2e-8,equal_nan=True)
            d[key]=max(d.get(key,0),float(np.nanmax(np.abs(a-b))))
        for key in ('calibration','calibration_ratios','calibration_cv','delta','pseudo_heritability','vg','ve'):
            a,b=base.extra[key],cur.extra[key]
            np.testing.assert_allclose(a,b,rtol=2e-6,atol=2e-8)
            d[key]=max(d.get(key,0),float(np.max(np.abs(np.asarray(a)-b))))
        assert base.extra['cg_iterations']==cur.extra['cg_iterations']
        finite=(base.p>0)&(cur.p>0)
        d['log10p']=max(d.get('log10p',0),float(np.max(abs(np.log10(base.p[finite])-np.log10(cur.p[finite])))))
    return d
