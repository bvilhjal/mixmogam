import numpy as np
from mixmogam import Genotypes

n, m = 4096, 6144
rng = np.random.default_rng(4971)
chrom = np.repeat(np.arange(1, 7), m // 6)
X = rng.standard_normal((n, 4))
G = np.empty((m, n), np.int8)
for idx in range(m):
    G[idx] = rng.binomial(2, rng.uniform(.05, .48), n)
causal = np.arange(17, m, 193)
score = rng.normal(size=causal.size) @ G[causal].astype(float)
y = .8 * score / np.std(score) + .15 * X[:, 0] + rng.normal(size=n)
for start in range(0, m, 128):
    part = G[start:start + 128]
    part[rng.random(part.shape) < .002] = -1
gt = Genotypes(G.T, chromosome=chrom, packed=True)
del G
